"""
Build feature columns for the dataframes (train, test)
TRICK: To apply only one function, change the feature engineering pipeline function and change input folder to processed

PARAMETERS
----------
    input_folder: input folder for the interim dataframes / processed
    output_folder: output folder for the procesed dataframes
    feature_engineering_pipeline: all the functions in this are applied sequentially to the input

FUNCTIONS
---------
common_feature_engineering_pipeline(df)
    common feature engineering functions for test and train
"""
import pandas as pd
import glob
import os 

from src.data.utils import feature_col
from src.data.comp.config import (
    # Competition specific config
    DATASET_NAME, LABELS, LABEL_COLS, SPLIT, RENAME_MAP, 
    # Mostly constants
    HOLDOUT_PERCENTAGE, NUM_FOLDS, RANDOM_STATE, 
    # Paths for the dataset
    RAW_DATA_PATH, INTERIM_DATA_PATH, PROCESSED_DATA_PATH, 
)
import src.data.comp.make_dataset

# Default values for the parameters
INPUT_FOLDER = INTERIM_DATA_PATH
OUTPUT_FOLDER = PROCESSED_DATA_PATH

# Main functions for feature engineering
def add_file_path(df, input_folder): 
    @feature_col
    def file_path(filepaths, img_id, study_id): 
        for filepath in filepaths: 
            if img_id in filepath and study_id in filepath: 
                return filepath
        return None
    glob_re = str(input_folder/ '**/*dcm')
    filepaths = glob.glob(glob_re, recursive=True)
    df = file_path(df, filepaths=filepaths)
    return df    

# Feature Engineering Pipeline
def common_feature_engineering_pipeline(df): 
    return df

def train_pipeline(train, **kwargs): 
    train = common_feature_engineering_pipeline(train)
    train = add_file_path(train, input_folder=RAW_DATA_PATH / 'train')
    train = train.reset_index(drop=True)
    return train 

def test_pipeline(test, **kwargs): 
    test = common_feature_engineering_pipeline(test)
    return test

def read_all_pkl_files(input_folder): 
    all_pkl_files_in_input_folder = glob.glob(str(input_folder / '**/*.pkl'), recursive=True)
    return all_pkl_files_in_input_folder

def get_output_path(input_path, input_folder, output_folder): 
    """
    Get output path for the dataframe by replacing input folder in the input path by output path
    """
    output_path = str(input_path).replace(str(input_folder), str(output_folder))
    return output_path

def apply_train_feature_engineering_pipeline(input_folder=INPUT_FOLDER, output_folder=OUTPUT_FOLDER, train_pipeline=train_pipeline): 
    all_pkl_files = read_all_pkl_files(input_folder)
    for pkl_path in all_pkl_files: 
        output_path = get_output_path(pkl_path, input_folder, output_folder)
        is_train = 'train' in pkl_path or 'valid' in pkl_path or 'holdout' in pkl_path
        if not is_train: continue
        df = pd.read_pickle(pkl_path)
        df = train_pipeline(df)
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        df.to_pickle(output_path)


def apply_test_feature_engineering_pipeline(raw_input_folder=RAW_DATA_PATH, test_pipeline=test_pipeline, output_folder=OUTPUT_FOLDER):
    test = src.data.comp.make_dataset.read_raw_test(raw_input_folder)
    test = test_pipeline(test)
    # save test so I can use it later
    save_path = output_folder / 'test.pkl'
    test.to_pickle(save_path)
    return test

if __name__ == '__main__': 
    apply_train_feature_engineering_pipeline()
    apply_test_feature_engineering_pipeline()
    
