"""
The main point of contact for other modules and function 
As long as everything in this works perfectly, the internals do not matter.
Focus on getting to this point as quickly as possible and iterate fast

API
---
read_dataframes
    read all the processed dataframes
    
"""
import pandas as pd
import glob
import os 

from src.data.utils import feature_col
from src.data.comp.config import (
    # Competition specific config
    DATASET_NAME, LABELS, LABEL_COLS, SPLIT, RENAME_MAP, 
    # Mostly constants
    HOLDOUT_PERCENTAGE, NUM_FOLDS, RANDOM_STATE, 
    # Paths for the dataset
    RAW_DATA_PATH, INTERIM_DATA_PATH, PROCESSED_DATA_PATH, 
)
import src.data.comp.build_features
import src.data.comp.make_dataset

# Constants to be imported 
FEATURE_COLS = ['file_path'] # X for the model
TARGET_COL = 'label' # y for the model

def read_dataframe(df_name, fold=0, debug_percentage='full', input_folder=PROCESSED_DATA_PATH): 
    df_path = input_folder / f'fold_{fold}' / debug_percentage / f'{df_name}.pkl'
    df = pd.read_pickle(df_path)
    return df

def read_dataframes(fold=0, debug_percentage='full', input_folder=PROCESSED_DATA_PATH):
    res = {}
    # read the files from the outer folder
    res['train_full'] = pd.read_pickle(input_folder / 'train_full.pkl')
    res['test'] = pd.read_pickle(input_folder / 'test.pkl')
    res['holdout'] = pd.read_pickle(input_folder / 'holdout.pkl')
    
    # read the files from the inner folder 
    inner_folder = input_folder / f'fold_{fold}' / debug_percentage
    os.makedirs(inner_folder, exist_ok=True)
    res['train'] = pd.read_pickle(inner_folder / 'train.pkl')
    res['valid'] = pd.read_pickle(inner_folder / 'valid.pkl')
    res['valid_75'] = pd.read_pickle(inner_folder / 'valid_75.pkl')
    res['valid_25'] = pd.read_pickle(inner_folder / 'valid_25.pkl')
    
    # make some testing files
    res['tr'] = res['train'].head(10)
    res['te'] = res['test'].head(5)
    res['val'] = res['valid'].head(5)
    
    return res
    

def read_test(input_folder=RAW_DATA_PATH): 
    test = src.data.comp.make_dataset.read_raw_test(input_folder)
    test = src.data.comp.build_features.apply_test_feature_engineering_pipeline(input_folder)
    return test


def read_input_file(file_path):
    return read_x 


if __name__ == '__main__':
    read_test()
    read_dataframes().keys()
    print('working!')