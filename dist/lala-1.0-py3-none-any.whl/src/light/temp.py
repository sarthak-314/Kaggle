CALLBACK_STORE = {}

callbacks = []

for obj in config: 
    load_obj(obj)