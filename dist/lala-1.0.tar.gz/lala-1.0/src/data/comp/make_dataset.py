"""
Builds interium dataframes for the dataset

PARAMETERS
----------
    input_folder: input folder for the raw dataframes
    output_folder: output folder for the final dataframes

MAIN FUNCTIONS 
---------------
read_raw_train(input_folder)
    read train dataframe from input folder

read_raw_test(input_folder)
    read test dataframe from input folder

read_raw_sample_sub(input_folder)
    read sample_sub from input folder     

add_intermediate_columns(train)
    add non feature columns like group and stratify to train 
    
sample_train(train, debug_percentage): 
    sample train according to sampling strategy

split_func(df): 
    splits dataframe into split_dfs and returns them 

main(input_folder, output_folder, build_options): 
    main functions to make dataset

⚒ Improvements & Ideas ⚒
-------------------------
- read omega conf documentation
- clean function descriptions and also the code
"""

import pandas as pd 
import numpy as np  
import glob
import os 

import src
import src.data.utils
import src.comp.utils

from src.data.comp.config import (
    # Competition specific config
    DATASET_NAME, LABELS, LABEL_COLS, SPLIT, RENAME_MAP, 
    # Mostly constants
    HOLDOUT_PERCENTAGE, NUM_FOLDS, RANDOM_STATE, 
    # Paths for the dataset
    RAW_DATA_PATH, INTERIM_DATA_PATH, PROCESSED_DATA_PATH, 
)

# Default values for the parameters
INPUT_FOLDER = RAW_DATA_PATH 
OUTPUT_FOLDER = INTERIM_DATA_PATH


def merge_input_dataframes(train_img, train_study):
    image_level_rename_map = { 'StudyInstanceUID': 'study_id', 'id': 'img_id' }
    train_img.id = train_img.id.str.replace('_image', '')
    train_img = train_img.rename(columns=image_level_rename_map)
    study_level_rename_map = {'id':'study_id'}
    train_study.id = train_study.id.str.replace('_study', '')
    train_study = train_study.rename(columns=study_level_rename_map)
    train = train_img.merge(train_study, on='study_id')
    return train

def read_raw_train(input_folder=INPUT_FOLDER):
    train_study = pd.read_csv(input_folder / 'train_study_level.csv')
    train_img = pd.read_csv(input_folder / 'train_image_level.csv')
    train = merge_input_dataframes(train_img, train_study)
    return train

def get_path_components(path): 
    normalized_path = os.path.normpath(path)
    path_components = normalized_path.split(os.sep)
    return path_components

def read_raw_test(input_folder=INPUT_FOLDER):
    filepaths = glob.glob(str(input_folder / 'test/**/*dcm'), recursive=True)
    test = pd.DataFrame({ 'img_path': filepaths })
    test['img_id'] = test.img_path.map(lambda x: get_path_components(x)[-1].replace('.dcm', ''))
    test['study_id'] = test.img_path.map(lambda x: get_path_components(x)[-3].replace('.dcm', ''))
    return test 

def read_raw_sample_sub(input_folder=INPUT_FOLDER):
    sample_sub = pd.read_csv(input_folder / 'sample_submission.csv')
    return sample_sub

def standardize_train(train): 
    # One hot encode and add labels
    train['one_hot'] = train[LABEL_COLS].apply(lambda row: row.values, axis='columns')
    train['label'] = train.one_hot.apply(lambda array: np.argmax(array))

    # Add stratify column and group column
    train['stratify'] = train['one_hot'].apply(str)
    train['group'] = train['study_id'].apply(str)
    
    return train

def sample_train_func(train, num_values_to_sample, random_state=RANDOM_STATE):
    return train.sample(num_values_to_sample, random_state=random_state)

def build_dataframes(input_folder=INPUT_FOLDER, output_folder=OUTPUT_FOLDER): 
    """
    Main function to build the dataframes and the folder

    Args:
        input_folder (Path): files read from here
        output_folder (Path): dataframes saved here
        build_options (OmegaConf): config dict to build the output
    """
    # Read input dataframes
    train, test, sample_sub = read_raw_train(input_folder), read_raw_test(input_folder), read_raw_sample_sub(input_folder)
    
    # Standardize train
    train = standardize_train(train)
    
    # Split train into holdout    
    train, holdout = src.data.utils.get_holdout(train, HOLDOUT_PERCENTAGE)
    pd.to_pickle(train, output_folder/ 'train_full.pkl')
    for df_name in ['test', 'holdout', 'sample_sub']: 
        df = eval(df_name)
        pd.to_pickle(df, output_folder / (df_name+'.pkl'))
    
    # Save the dataframes
    build_fold_dfs = lambda df: src.data.utils.get_fold_dfs(df, 'group', NUM_FOLDS)
    src.data.utils.save_dataframes(train, sample_train_func, build_fold_dfs, NUM_FOLDS, RANDOM_STATE, output_folder)
    
    
if __name__ == '__main__':
    build_dataframes()