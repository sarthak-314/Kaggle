from pathlib import Path 

SRC_PACKAGE_PATH = Path('C:\\Users\\sarth\\Desktop\\kaggle-v2\\src')
INPUT_PATH = Path('C:\\Users\\sarth\\Desktop\\kaggle-v2')