# Pipeline for Data
Download -> Make datasets -> Feature Engineering -> Build Datasets -> TorchDataset -> Datamodule -> model


# Baselines

## No aug + single backbone baseline 
Try to iterate fast and make a no aug - single backbone baseline within a day. Try to reach silver with this

## Basic aug + single backbone baseline
